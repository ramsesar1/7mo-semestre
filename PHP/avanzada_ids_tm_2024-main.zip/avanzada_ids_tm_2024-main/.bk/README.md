# avanzada_ids_tm_2024
Repositorio de la clase programación avanzada TM 2024
